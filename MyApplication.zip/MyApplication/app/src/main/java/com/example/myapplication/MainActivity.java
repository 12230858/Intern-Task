package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView etaText;
    private Button hailButton;
    private Button cancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etaText = findViewById(R.id.eta_text);
        hailButton = findViewById(R.id.hail_button);
        cancelButton = findViewById(R.id.cancel_button);

        // Fetch ETA using mock API
//        String eta = MockApi.fetchEta();
        etaText.setText("Press the Hail button for call the Bus");

        hailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hailBus();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelHail();
            }
        });
    }

    private void hailBus() {
        if (MockApi.sendHailRequest()) {
            etaText.setText("Hail request sent. ETA: " + MockApi.fetchEta());
            Toast.makeText(MainActivity.this, "Bus has been hailed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "Failed to hail the bus", Toast.LENGTH_SHORT).show();
        }
    }

    private void cancelHail() {
        if (MockApi.cancelHailRequest()) {
            etaText.setText("Hail request cancelled.");
            Toast.makeText(MainActivity.this, "Hail request has been cancelled", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "Failed to cancel the hail request", Toast.LENGTH_SHORT).show();
        }
    }
}