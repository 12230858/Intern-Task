package com.example.myapplication;

import java.util.Random;

public class MockApi {

    public static String fetchEta() {
        // Create an instance of the Random class
        Random random = new Random();

        // Generate a random number between 1 and 20 (inclusive)
        int etaMinutes = random.nextInt(20) + 1;

        // Return the random ETA as a string
        return etaMinutes + " minutes";
    }


    public static boolean sendHailRequest() {
        // Simulate sending a hail request to an API
        return true;
    }

    public static boolean cancelHailRequest() {
        // Simulate cancelling a hail request via an API
        return true;
    }
}